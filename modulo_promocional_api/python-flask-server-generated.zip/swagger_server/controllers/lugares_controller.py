import connexion
import six

from swagger_server.models.request_get_ciudades import RequestGetCiudades  # noqa: E501
from swagger_server.models.request_get_provincia import RequestGetProvincia  # noqa: E501
from swagger_server.models.request_get_sectores import RequestGetSectores  # noqa: E501
from swagger_server.models.response_error import ResponseError  # noqa: E501
from swagger_server.models.response_get_ciudad_data import ResponseGetCiudadData  # noqa: E501
from swagger_server.models.response_get_provincia_data import ResponseGetProvinciaData  # noqa: E501
from swagger_server.models.response_get_sectores_data import ResponseGetSectoresData  # noqa: E501
from swagger_server import util


def get_ciudades(body=None):  # noqa: E501
    """get_ciudades

    Consulta de Datos de Ciudades # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ResponseGetCiudadData
    """
    if connexion.request.is_json:
        body = RequestGetCiudades.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_provincias(body=None):  # noqa: E501
    """get_provincias

    Consulta de Datos de Provincias segun sus parametros. # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ResponseGetProvinciaData
    """
    if connexion.request.is_json:
        body = RequestGetProvincia.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_sectores(body=None):  # noqa: E501
    """get_sectores

    Consulta de Datos de Sectores # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ResponseGetSectoresData
    """
    if connexion.request.is_json:
        body = RequestGetSectores.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
