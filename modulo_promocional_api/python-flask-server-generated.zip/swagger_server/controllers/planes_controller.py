import connexion
import six

from swagger_server.models.request_get_combos import RequestGetCombos  # noqa: E501
from swagger_server.models.request_get_ofertas import RequestGetOfertas  # noqa: E501
from swagger_server.models.request_get_planes import RequestGetPlanes  # noqa: E501
from swagger_server.models.request_get_servicios import RequestGetServicios  # noqa: E501
from swagger_server.models.response_combos_data import ResponseCombosData  # noqa: E501
from swagger_server.models.response_error import ResponseError  # noqa: E501
from swagger_server.models.response_get_planes_data import ResponseGetPlanesData  # noqa: E501
from swagger_server.models.response_ofertas_data import ResponseOfertasData  # noqa: E501
from swagger_server.models.response_servicios_data import ResponseServiciosData  # noqa: E501
from swagger_server import util


def get_combos(body=None):  # noqa: E501
    """get_combos

    Consulta de Datos de Combos # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ResponseCombosData
    """
    if connexion.request.is_json:
        body = RequestGetCombos.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_ofertas(body=None):  # noqa: E501
    """get_ofertas

    Consulta de Datos de Ofertas # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ResponseOfertasData
    """
    if connexion.request.is_json:
        body = RequestGetOfertas.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_planes(body=None):  # noqa: E501
    """get_planes

    Consulta de Datos de Planes # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ResponseGetPlanesData
    """
    if connexion.request.is_json:
        body = RequestGetPlanes.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_servicios(body=None):  # noqa: E501
    """get_servicios

    Consulta de Datos de Servicios # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ResponseServiciosData
    """
    if connexion.request.is_json:
        body = RequestGetServicios.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
